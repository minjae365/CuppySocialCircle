//
//  PetRepo.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import Foundation

class PetRepository {
    private let PET_KEY_PREFIX = "PET_KEY_"
    private var pet: Pet
    private var currentUser: String

    init(currentUser: String = "defaultUser") {
        self.currentUser = currentUser

        // Load user-specific pet data
        let petKey = "\(PET_KEY_PREFIX)\(currentUser)"
        if let data = UserDefaults.standard.data(forKey: petKey),
           let decoded = try? JSONDecoder().decode(Pet.self, from: data) {
            self.pet = decoded
            print("Pet successfully retrieved for user: \(currentUser)")
        } else {
            // Create a new pet for the user
            self.pet = Pet(name: "Cuppy", birthday: Date(), caffeineCount: 0, totalSpent: 0)
        }
    }

    func loadData() -> Pet {
        return pet
    }

    func saveData(pet: Pet) {
        let petKey = "\(PET_KEY_PREFIX)\(currentUser)"
        if let encoded = try? JSONEncoder().encode(pet) {
            UserDefaults.standard.set(encoded, forKey: petKey)
            print("Pet data saved for user: \(currentUser)")
        }
    }
}
