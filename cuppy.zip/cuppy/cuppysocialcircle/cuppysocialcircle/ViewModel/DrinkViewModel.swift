//
//  DrinkViewModel.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-21.
//

import Foundation

class DrinkViewModel: ObservableObject {
    @Published var drinks: [Drink] = []
    private var userID: String
    
    var lastLogDate: Date? {
            return drinks.flatMap { $0.logTimes }.max()
        }

    init(userID: String = "Default User") {
        self.userID = userID
        loadDrinks()
    }

    // Load drinks from JSON specific to the user
    private func loadDrinks() {
        let url = getDocumentsDirectory().appendingPathComponent("\(userID)_DrinkData.json")
        if !FileManager.default.fileExists(atPath: url.path) {
            if let bundleUrl = Bundle.main.url(forResource: "DrinkData", withExtension: "json") {
                try? FileManager.default.copyItem(at: bundleUrl, to: url)
            }
        }
        do {
            let data = try Data(contentsOf: url)
            drinks = try JSONDecoder().decode([Drink].self, from: data)
            addMissingIDs() // Ensure IDs are consistent
            print("Drinks Loaded for \(userID): \(drinks)") // Debug print
        } catch {
            print("Error loading drinks: \(error.localizedDescription)")
        }
    }
    
    // Save drinks to JSON specific to the user
    private func saveDrinks() {
        let url = getDocumentsDirectory().appendingPathComponent("\(userID)_DrinkData.json")
        do {
            let data = try JSONEncoder().encode(drinks)
            try data.write(to: url)
        } catch {
            print("Error saving drinks: \(error.localizedDescription)")
        }
    }

    // Ensure all drinks have unique IDs
    private func addMissingIDs() {
        var updated = false
        for i in 0..<drinks.count {
            if drinks[i].id == UUID() {
                drinks[i].id = UUID() // Assign new ID if missing
                updated = true
            }
        }
        if updated {
            saveDrinks() // Save changes back to JSON
        }
    }

    // Log a drink (update count and time)
    func logDrink(name: String, caffeineLevel: Int, price: Double, calories: Int) {
        if let index = drinks.firstIndex(where: { $0.name == name }) {
            // Update existing drink entry
            drinks[index].count += 1
            drinks[index].logTimes.append(Date())
        } else {
            // Add a new drink entry
            drinks.append(Drink(
                name: name,
                caffeine: caffeineLevel,
                calories: calories,
                count: 1,
                logTimes: [Date()],
                price: price
            ))
        }
        saveDrinks()
    }

    // Add a new custom drink
    func addCustomDrink(name: String, calories: Int, caffeine: Int) {
        let newDrink = Drink(name: name, caffeine: caffeine, calories: calories, count: 1, logTimes: [Date()], price: 0)
        drinks.append(newDrink)
        saveDrinks()
    }

    // Helper to get the app's Documents directory
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    func clearTodayLogs() {
        let calendar = Calendar.current
        let today = Date()
        
        for i in 0..<drinks.count {
            drinks[i].logTimes.removeAll { logTime in
                calendar.isDate(logTime, inSameDayAs: today)
            }
            if drinks[i].logTimes.isEmpty {
                drinks[i].count = 0
            } else {
                drinks[i].count = drinks[i].logTimes.count
            }
        }
        
        saveDrinks() // Save the updated data
    }
}

struct Drink: Identifiable, Codable {
    var id = UUID()
    let name: String
    let caffeine: Int
    let calories: Int
    var count: Int // Track how many times this drink has been logged
    var price: Double
    var logTimes: [Date] = [] // Track when this drink was logged
    
    init(name: String, caffeine: Int, calories: Int, count: Int, logTimes: [Date], price: Double) {
            self.id = UUID() // Generate a unique ID
            self.name = name
            self.caffeine = caffeine
            self.calories = calories
            self.count = count
            self.logTimes = logTimes
            self.price = price
        }
}

extension DrinkViewModel {
    var totalCaffeine: Int {
        drinks.reduce(into: 0) { $0 + ($1.caffeine * $1.count) }
    }

    var totalSpending: Double {
        drinks.reduce(into: 0) { $0 + ($1.price * Double($1.count)) }
    }
}

