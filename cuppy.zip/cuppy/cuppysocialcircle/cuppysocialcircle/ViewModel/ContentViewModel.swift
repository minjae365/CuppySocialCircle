//
//  ContentViewModel.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import Foundation
import SwiftUI

extension HomeView {
    class ViewModel: ObservableObject {
        @Published var pet: Pet
        private let repository: PetRepository

        init(repository: PetRepository) {
            self.repository = repository
            self.pet = repository.loadData()
        }
        
        func savePetData() {
            objectWillChange.send()
            repository.saveData(pet: pet)
        }
        
        func logCaffeineIntake() {
            pet.caffeineCount += 1
            savePetData()
        }
        
        func addSpending(amount: Int) {
            pet.totalSpent += amount
            savePetData()
        }
        
        func resetSpending() {
            pet.totalSpent = 0
            savePetData()
        }
        
        func updateStreak(isWithinLimits: Bool) {
            objectWillChange.send()
            if isWithinLimits {
                pet.incrementStreak()
            } else {
                pet.resetStreak()
            }
            repository.saveData(pet: pet)
        }

        func checkStreak(todayLogged: Bool) {
            // If no input logged for today, reset streak
            if !todayLogged {
                updateStreak(isWithinLimits: false)
            }
        }
    }
}
