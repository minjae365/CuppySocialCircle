//
//  AppViewModel.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-18.
//

import Foundation
import SwiftUI

enum ControlPreference: String {
    case caffeine, spending, both
}

@MainActor // Ensure it runs on the main thread
class AppViewModel: ObservableObject {
    // Global loading state
    @Published var isLoading: Bool = false
    @AppStorage("hasCompletedTutorial") var hasCompletedTutorial: Bool = false
    @Published var notificationFrequency: Int = 2
    @Published var drinkLimit: Int = 3
    @Published var caffeineLimit: Int = 2
    @Published var spendingLimit: Double = 10.0
    @Published var notificationsEnabled: Bool = true
    @Published var controlPreference: ControlPreference = .both
    @Published var petStatus: Int = 1 // 1 = healthy, 4 = dead
    @Published var isUserAuthenticated: Bool = false // Tracks authentication status
    private let lastResetDateKey = "lastResetDate" // UserDefaults key for last reset date
    
    // Current User
    @Published var currentUser: String? {
        didSet {
            if let user = currentUser {
                petRepository = PetRepository(currentUser: user)
                drinkViewModel = DrinkViewModel(userID: user)
                loadLastResetDate()
            }
        }
    }

    // User-specific repositories
    @Published var petRepository: PetRepository?
    @Published var drinkViewModel: DrinkViewModel?

    init() {
        // Load the current user from UserDefaults
        if let savedUser = UserDefaults.standard.string(forKey: "currentUser") {
            currentUser = savedUser
            isUserAuthenticated = true
        } else {
            isUserAuthenticated = false
        }

        // Ensure user data is initialized
        if let user = currentUser {
            petRepository = PetRepository(currentUser: user)
            drinkViewModel = DrinkViewModel(userID: user)
            checkForDailyReset(lastLogDate: drinkViewModel?.lastLogDate)
        }
    }

    func updatePetStatus(caffeineLimit: Int, spendingLimit: Double, caffeineConsumed: Int, moneySpent: Double) {
        switch controlPreference {
        case .caffeine:
            petStatus = caffeineConsumed > caffeineLimit ? 3 : 1
        case .spending:
            petStatus = moneySpent > spendingLimit ? 3 : 1
        case .both:
            if caffeineConsumed > caffeineLimit && moneySpent > spendingLimit {
                petStatus = 4
            } else if caffeineConsumed > caffeineLimit || moneySpent > spendingLimit {
                petStatus = 3
            } else {
                petStatus = 1
            }
        }
    }

    func checkForDailyReset(lastLogDate: Date?) {
        let now = Date()
        let calendar = Calendar.current

        // Check if it's a new day
        let isNewDay = lastLogDate == nil || !calendar.isDate(lastLogDate!, inSameDayAs: now)

        // Perform reset if the pet is dead or no logs for the current day
        if isNewDay {
            resetPetStatus()
            resetDailyLogs()
        }
    }

    private func resetPetStatus() {
        petStatus = 1 // Reset to healthy state
        UserDefaults.standard.set(Date(), forKey: lastResetDateKey) // Update reset date
    }

    private func resetDailyLogs() {
        // Clear today's logs from the drink view model
        drinkViewModel?.clearTodayLogs()
    }

    private func loadLastResetDate() {
        // Load the last reset date from UserDefaults
        if let lastReset = UserDefaults.standard.object(forKey: lastResetDateKey) as? Date {
            if !Calendar.current.isDateInToday(lastReset) {
                resetPetStatus()
            }
        }
    }
}
