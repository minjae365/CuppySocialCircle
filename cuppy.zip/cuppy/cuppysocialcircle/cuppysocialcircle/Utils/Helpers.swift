//
//  Helpers.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import Foundation
import SwiftUI

/// Calculates the time (in days) since a given date.
func calculateDaysSince(date: Date) -> Int {
    let calendar = Calendar.current
    let startOfDay = calendar.startOfDay(for: date)
    let today = calendar.startOfDay(for: Date())
    let components = calendar.dateComponents([.day], from: startOfDay, to: today)
    return components.day ?? 0
}
    
/// View extension for horizontally centering a view with spacers.
extension View {
    func centeredHorizontally() -> some View {
        HStack {
            Spacer()
            self
            Spacer()
        }
    }
}

