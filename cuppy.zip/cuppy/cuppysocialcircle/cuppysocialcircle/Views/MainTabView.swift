//
//  MainTabView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-20.
//

import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var appViewModel: AppViewModel
    @StateObject private var drinkViewModel = DrinkViewModel()

    var body: some View {
        TabView {
            NavigationStack {
                HomeView()
                    .navigationTitle("Home")
            }
            .tabItem {
                Label("Home", systemImage: "house")
            }
            .environmentObject(drinkViewModel)

            NavigationStack {
                GraphsView()
                    .navigationTitle("Graphs")
            }
            .tabItem {
                Label("Graphs", systemImage: "chart.bar")
            }
            .environmentObject(drinkViewModel)

            NavigationStack {
                TableView()
                    .navigationTitle("Table")
            }
            .tabItem {
                Label("Table", systemImage: "table")
            }
            .environmentObject(drinkViewModel)

            NavigationStack {
                LeaderboardView()
                    .navigationTitle("Leaderboard")
            }
            .tabItem {
                Label("Leaderboard", systemImage: "person.3")
            }
            .environmentObject(drinkViewModel)
        }
        .accentColor(Color("Celadon"))
    }
}


#Preview {
    MainTabView()
        .environmentObject(AppViewModel())
        .environmentObject(DrinkViewModel())
}


//private func highlightColor(for tab: Tab) -> Color {
//    switch tab {
//    case .home: return Color("Celadon") // Highlight color for Home
//    case .graphs: return Color("Bistre") // Highlight color for Graphs
//    case .leaderboard: return Color("Celadon") // Highlight color for Leaderboard
//    case .table: return Color("Bistre") // Highlight color for Table
//    }
