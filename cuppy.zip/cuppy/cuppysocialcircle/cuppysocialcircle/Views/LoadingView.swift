//
//  LoadingView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-18.
//

import Foundation
import SwiftUI

struct LoadingView: View {
    var body: some View {
        ZStack {
            // Background color (optional)
            Color.white
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                // Mascot Animation
                LottieView(filename: "loading") // Replace with your mascot animation filename
                    .frame(width: 200, height: 200)
                    .scaledToFit()
                
                // Loading Text
                Text("Loading...")
                    .font(.headline)
                    .foregroundColor(.gray)
                    .padding(.top, 20)
            }
        }
    }
}

#Preview {
    LoadingView()
}
