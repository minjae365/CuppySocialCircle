import Foundation
import SwiftUI

struct LoginView: View {
    @EnvironmentObject var appViewModel: AppViewModel // Access global app state
    @State private var id: String = ""
    @State private var password: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    @AppStorage("userSignedIn") private var userSignedIn: Bool = false

    private let credentialManager = CredentialManager()

    var body: some View {
        NavigationStack {
            ZStack {
                Color("Beige").edgesIgnoringSafeArea(.all) // Background color

                VStack(spacing: 20) {
                    // Mascot Animation
                    LottieView(filename: "loading")
                        .frame(width: 200, height: 200)
                        .scaledToFit()

                    Text("Welcome Back!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(Color("Bistre"))

                    // User ID Input
                    TextField("Enter your ID", text: $id)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                        .padding(.horizontal)
                        .background(Color.white)
                        .cornerRadius(10)

                    // Password Input
                    SecureField("Enter your Password", text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                        .background(Color.white)
                        .cornerRadius(10)

                    // Login Button
                    Button(action: login) {
                        Text("Log In")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color("Celadon")) // Button color
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)

                    // Sign Up Navigation
                    NavigationLink(
                        destination: SignUpView().environmentObject(appViewModel),
                        label: {
                            Text("Sign Up")
                                .foregroundColor(Color("Bistre"))
                        }
                    )
                }
                .padding()
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Login"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
            }
            .fullScreenCover(isPresented: $appViewModel.isUserAuthenticated) {
                MainTabView()
                    .environmentObject(appViewModel)
                    .environmentObject(DrinkViewModel())
            }
        }
    }

    private func login() {
        guard !id.isEmpty, !password.isEmpty else {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        if credentialManager.idExists(id: id) {
            if credentialManager.validateCredentials(id: id, password: password) {
                alertMessage = "Login Successful!"
                appViewModel.isUserAuthenticated = true // Navigate to MainTabView
            } else {
                alertMessage = "Incorrect password."
            }
        } else {
            alertMessage = "ID does not exist."
        }
        showAlert = true
    }
}
