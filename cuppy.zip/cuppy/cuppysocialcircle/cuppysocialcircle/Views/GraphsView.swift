import SwiftUI
import Charts

struct GraphsView: View {
    @EnvironmentObject var appViewModel: AppViewModel
    @EnvironmentObject var drinkViewModel: DrinkViewModel
    @State private var selectedFilter: String = "Weekly"
    private let filters = ["Weekly", "Monthly"]

    var body: some View {
        ZStack {
            // Background color
            Color("Beige").edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(spacing: 16) {
                    // Dropdown Filter
                    Picker("Select View", selection: $selectedFilter) {
                        ForEach(filters, id: \.self) { filter in
                            Text(filter)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                    .background(Color("Beige"))
                    .cornerRadius(8)
                    .shadow(radius: 2)

                    // Caffeine Intake Graph
                    if !filteredCaffeineData.isEmpty {
                        Text("Caffeine Intake")
                            .font(.headline)
                            .foregroundColor(Color("Bistre"))

                        Chart(filteredCaffeineData) {
                            BarMark(
                                x: .value("Date", $0.date, unit: .day),
                                y: .value("Drinks", $0.count)
                            )
                            .foregroundStyle(Color("Celadon"))
                            .lineStyle(.init(lineWidth: 2)) // Thicker line
                        }
                        .frame(height: 300)
                        .padding(.horizontal)
                    } else {
                        EmptyStateView(message: "No caffeine intake logged for the selected period.")
                            .padding(.horizontal)
                    }

                    // Spending Habits Graph
                    if !filteredSpendingData.isEmpty {
                        Text("Spending Habits")
                            .font(.headline)
                            .foregroundColor(Color("Bistre"))

                        Chart(filteredSpendingData) {
                            LineMark(
                                x: .value("Date", $0.date, unit: .day),
                                y: .value("Spending", $0.amount)
                            )
                            .foregroundStyle(Color("Bistre"))
                            .lineStyle(.init(lineWidth: 2)) // Thicker line
                        }
                        .frame(height: 300)
                        .padding(.horizontal)
                    } else {
                        EmptyStateView(message: "No spending data logged for the selected period.")
                            .padding(.horizontal)
                    }

                    Spacer()
                }
                .navigationTitle("Graphs")
            }
        }
    }

    // Filtered Caffeine Data
    private var filteredCaffeineData: [GraphData] {
        let calendar = Calendar.current
        let now = Date()

        return drinkViewModel.drinks.flatMap { drink in
            drink.logTimes.filter { logTime in
                switch selectedFilter {
                case "Weekly":
                    return calendar.isDate(logTime, equalTo: now, toGranularity: .weekOfYear)
                case "Monthly":
                    return calendar.isDate(logTime, equalTo: now, toGranularity: .month)
                default:
                    return false
                }
            }
            .map { logTime in
                GraphData(date: logTime, count: drink.count, amount: 0)
            }
        }
    }

    // Filtered Spending Data
    private var filteredSpendingData: [GraphData] {
        let calendar = Calendar.current
        let now = Date()

        return drinkViewModel.drinks.flatMap { drink in
            drink.logTimes.filter { logTime in
                switch selectedFilter {
                case "Weekly":
                    return calendar.isDate(logTime, equalTo: now, toGranularity: .weekOfYear)
                case "Monthly":
                    return calendar.isDate(logTime, equalTo: now, toGranularity: .month)
                default:
                    return false
                }
            }
            .map { logTime in
                GraphData(
                    date: logTime,
                    count: 0,
                    amount: drink.price * Double(drink.count)
                )
            }
        }
    }
}

// MARK: - Helper Views

struct EmptyStateView: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.headline)
            .foregroundColor(.gray)
            .multilineTextAlignment(.center)
            .padding()
    }
}

// MARK: - Data Model for Graphs

struct GraphData: Identifiable {
    let id = UUID()
    let date: Date
    let count: Int
    let amount: Double
}

// MARK: - Preview

#Preview {
    GraphsView()
        .environmentObject(AppViewModel())
        .environmentObject(DrinkViewModel())
}
