//
//  HomeView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import SwiftUI
import Lottie

struct HomeView: View {
    @StateObject private var vm: ViewModel
    @EnvironmentObject var appViewModel: AppViewModel
    @EnvironmentObject var drinkViewModel: DrinkViewModel
    @State private var selectedDrink: String = "Espresso"
    @State private var drinkPrice: String = ""
    @State private var showSettings: Bool = false
    @State private var showInputAnimation: Bool = false
    @State private var showCustomDrinkPopup: Bool = false
    @State private var drinkOptions: [String] = ["Espresso", "Energy Drink", "Tea", "Others"]

    init() {
        // Ensure `currentUser` is passed properly
        let currentUser = UserDefaults.standard.string(forKey: "currentUser") ?? "defaultUser"
        _vm = StateObject(wrappedValue: ViewModel(repository: PetRepository(currentUser: currentUser)))
    }

    var body: some View {
        ZStack {
            Color("Beige").edgesIgnoringSafeArea(.all) // Beige background

            ScrollView {
                VStack {
                    // Top Section: Streak and Mascot
                    HStack {
                        Spacer()
                        StreakView(streakCount: vm.pet.streakCount)
                            .padding(.trailing, 20)
                    }

                    ZStack {
                        Color.clear
                        Image(getPetImageName(for: appViewModel.petStatus))
                            .resizable()
                            .scaledToFit()
                            .frame(width: 300, height: 300) // Resize
                    }
                    .frame(height: 300)

                    Text(getPetMessage(for: appViewModel.petStatus))
                        .font(.headline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color("Celadon").opacity(0.2)) // Celadon background
                        )
                        .padding(.bottom, 20)

                    // Input Section: Drink Logger
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Log Your Drink")
                            .font(.headline)
                            .foregroundColor(Color("Bistre"))

                        Picker("Select Drink", selection: $selectedDrink) {
                            ForEach(drinkOptions, id: \.self) { drink in
                                Text(drink)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .onChange(of: selectedDrink) { newValue in
                            if newValue == "Others" {
                                showCustomDrinkPopup = true
                            }
                        }

                        if selectedDrink != "Others" {
                            TextField("Enter drink cost", text: $drinkPrice)
                                .keyboardType(.decimalPad)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .background(Color("Beige"))

                            Button(action: logDrink) {
                                Text("Add Drink")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color("Celadon"))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                        }
                    }
                    .padding(.horizontal)

                    Spacer()
                }
                .navigationTitle("Home")
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(action: { showSettings.toggle() }) {
                            Image(systemName: "gearshape")
                                .foregroundColor(Color("Bistre"))
                                .imageScale(.large)
                        }
                    }
                }
                .sheet(isPresented: $showSettings) {
                    SettingsView()
                        .environmentObject(appViewModel)
                }
                .onReceive(Timer.publish(every: 15, on: .main, in: .common)) { _ in
                    vm.savePetData()
                }
                .onAppear {
                    appViewModel.updatePetStatus(
                        caffeineLimit: appViewModel.caffeineLimit,
                        spendingLimit: appViewModel.spendingLimit,
                        caffeineConsumed: vm.pet.caffeineCount,
                        moneySpent: Double(vm.pet.totalSpent)
                    )
                }

                // Custom Drink Pop-Up
                if showCustomDrinkPopup {
                    CustomDrinkPopup(
                        isPresented: $showCustomDrinkPopup,
                        drinkOptions: $drinkOptions,
                        onSave: { name, calories, caffeine in
                            addCustomDrink(name: name, calories: calories, caffeine: caffeine)
                        }
                    )
                }

                // Input Animation Overlay
                if showInputAnimation {
                    InputAnimationView(
                        show: $showInputAnimation,
                        animationName: "inputSavedAnimation",
                        animationDuration: 2.0
                    )
                }
            }
            .safeAreaInset(edge: .top, spacing: 0) {
                Color.clear.frame(height: 16) // Ensure padding for top safe area
            }
        }
    }

    private func logDrink() {
        guard let price = Double(drinkPrice) else {
            print("Invalid price entered")
            return
        }

        // Retrieve caffeine level and calories for the selected drink
        let drinkData = getDrinkData(for: selectedDrink)
        let caffeineLevel = drinkData?.caffeineLevel ?? 0
        let calories = drinkData?.calories ?? 0

        // Update Pet data
        vm.pet.caffeineCount += caffeineLevel
        vm.pet.totalSpent += Int(price)

        // Log the drink
        drinkViewModel.logDrink(name: selectedDrink, caffeineLevel: caffeineLevel, price: price, calories: calories)
        vm.savePetData()

        // Reset input and trigger animation
        drinkPrice = ""
        showInputAnimation = true
    }

    private func getDrinkData(for drinkName: String) -> (caffeineLevel: Int, calories: Int)? {
        let drinkDatabase: [String: (caffeineLevel: Int, calories: Int)] = [
            "Espresso": (caffeineLevel: 64, calories: 2),
            "Energy Drink": (caffeineLevel: 80, calories: 110),
            "Tea": (caffeineLevel: 26, calories: 2)
        ]

        return drinkDatabase[drinkName]
    }

    private func addCustomDrink(name: String, calories: Int, caffeine: Int) {
        drinkOptions.insert(name, at: drinkOptions.count - 1) // Add before "Others"
        drinkViewModel.addCustomDrink(name: name, calories: calories, caffeine: caffeine) // Save to JSON
    }

    private func getPetImageName(for status: Int) -> String {
        switch status {
        case 1: return "first"
        case 2: return "second"
        case 3: return "third"
        case 4: return "fourth"
        default: return "first"
        }
    }

    private func getPetMessage(for status: Int) -> String {
        let messages: [String]

        switch status {
        case 1:
            messages = [
                "You're doing great! Keep it up!",
                "I'm so proud of you!",
                "We're crushing it together!"
            ]
        case 2:
            messages = [
                "Caffeine takes about 15 minutes to kick in and can last in your system for up to 6 hours!",
                "Drinking coffee can improve your focus, but too much might make you jittery!",
                "Decaf coffee still contains a tiny amount of caffeine, so it’s not 100% caffeine-free!",
                "Energy drinks contain caffeine, but watch out for the high sugar content—they might give you a crash later!"
            ]
        case 3:
            messages = [
                "I'm not feeling so good...",
                "This isn't looking great for us.",
                "Try to stick to your goals!",
                "Maybe some water? You've been drinking too much",
                "Ever heard of yerba mate? It’s a natural energy drink packed with caffeine and nutrients!"
            ]
        case 4:
            messages = [
                "I'm gone... Please take care of yourself.",
                "Goodbye... Maybe next time.",
                "I hope you learn from this."
            ]
        default:
            messages = ["Let's do our best together!"]
        }

        return messages.randomElement() ?? "Let's do our best together!"
    }
}



// MARK: - Helper Subviews

struct StreakView: View {
    let streakCount: Int

    var body: some View {
        HStack {
            Image(systemName: "flame.fill")
                .foregroundColor(Color.orange)
            Text("\(streakCount) Day Streak")
                .font(.headline)
                .foregroundColor(Color.orange)
        }
        .padding(10)
        .background(Capsule().fill(Color("Bistre").opacity(0.1))) // Bistre background
    }
}

struct CustomDrinkPopup: View {
    @Binding var isPresented: Bool
    @Binding var drinkOptions: [String]
    var onSave: (String, Int, Int) -> Void

    @State private var drinkName: String = ""
    @State private var drinkCalories: String = ""
    @State private var drinkCaffeine: String = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Add Custom Drink")
                .font(.headline)

            TextField("Drink Name", text: $drinkName)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Calories", text: $drinkCalories)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Caffeine Level (mg)", text: $drinkCaffeine)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            HStack {
                Button("Cancel") {
                    isPresented = false
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.gray)
                .foregroundColor(.white)
                .cornerRadius(10)

                Button("Save") {
                    guard let calories = Int(drinkCalories), let caffeine = Int(drinkCaffeine) else {
                        print("Invalid custom drink inputs")
                        return
                    }
                    onSave(drinkName, calories, caffeine)
                    isPresented = false
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color("Celadon"))
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .padding()
        .background(Color("Beige").cornerRadius(20))
        .shadow(radius: 10)
        .frame(maxWidth: 300)
    }
}

// MARK: - Preview

#Preview {
    NavigationView {
        HomeView()
            .environmentObject(AppViewModel())
            .environmentObject(DrinkViewModel())
    }
}
