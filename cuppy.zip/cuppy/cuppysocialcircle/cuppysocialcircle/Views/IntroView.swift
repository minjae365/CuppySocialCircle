//
//  IntroView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-17.
//

import Foundation
import SwiftUI

struct IntroView: View {
    var body: some View {
        VStack {
            Spacer()
            
            // Mascot Section
            VStack {
                LottieView(filename: "introMascot") // Replace with your mascot's Lottie animation
                    .frame(width: 200, height: 200)
                    .scaledToFit()
                Text("Welcome to Cuppy's Circle!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .padding(.top, 10)
                Text("Your friendly companion for reducing caffeine and saving money.")
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding()
            
            Spacer()
            
            // Navigation to Login
            NavigationLink(destination: LoginView()) {
                Text("Get Started")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .navigationBarHidden(true)
    }
}

#Preview {
    NavigationView {
        IntroView()
    }
}
