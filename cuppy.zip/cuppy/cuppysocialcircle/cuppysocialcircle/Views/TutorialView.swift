//
//  TutorialView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-18.
//

import Foundation
import SwiftUI

struct TutorialView: View {
    @State private var currentStep: Int = 0
    @State private var notificationFrequency: Int = 2 // Default value
    @State private var notificationTimes: [Date] = [] // Store scheduled times
    @State private var cupLimit: Int = 3 // Default value
    @State private var spendingLimit: Double = 10.0 // Default value
    @State private var controlPreference: ControlPreference = .both // Default to both

    @AppStorage("hasCompletedTutorial") private var hasCompletedTutorial: Bool = false
    @EnvironmentObject var appViewModel: AppViewModel // Access global states
    @Environment(\.presentationMode) var presentationMode // For dismissing the view if needed

    var body: some View {
        VStack {
            Spacer()

            // Mascot Animation
            LottieView(filename: "First_second") // Replace with your mascot animation filename
                .frame(width: 200, height: 200)
                .scaledToFit()

            Spacer()

            // Step Content
            VStack(spacing: 20) {
                switch currentStep {
                case 0:
                    Text("Hi! I'm Cuppy, your friendly mascot!")
                        .font(.title2)
                        .multilineTextAlignment(.center)
                    Text("Let’s set up your preferences!")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                case 1:
                    Text("How often would you like to be notified?")
                        .font(.title2)
                    Stepper("Notifications: \(notificationFrequency) times/day", value: $notificationFrequency, in: 1...10)
                case 2:
                    Text("What do you want to control?")
                        .font(.title2)
                    Picker("Choose:", selection: $controlPreference) {
                        Text("Caffeine").tag(ControlPreference.caffeine)
                        Text("Spending").tag(ControlPreference.spending)
                        Text("Both").tag(ControlPreference.both)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                case 3:
                    Text("What's your daily limit for caffeinated drinks?")
                        .font(.title2)
                    Stepper("Limit: \(cupLimit) cups/day", value: $cupLimit, in: 1...10)
                case 4:
                    Text("What's your daily spending limit?")
                        .font(.title2)
                    HStack {
                        Text("Limit: $\(spendingLimit, specifier: "%.2f")")
                        Spacer()
                        Slider(value: $spendingLimit, in: 1...50, step: 1.0)
                    }
                case 5:
                    Text("You're all set!")
                        .font(.title2)
                    Text("But remember... ")
                        .font(.subheadline)
                    Text("I will die if you dont keep our promise... ")
                        .font(.subheadline)
                    Text("Please drink and spend responsiblely!")
                        .font(.subheadline)
                default:
                    EmptyView()
                }
            }
            .padding()

            Spacer()

            // Navigation Buttons
            HStack {
                if currentStep < 5 {
                    Button("Skip Tutorial") {
                        skipTutorial()
                    }
                    .foregroundColor(.red)
                    .padding()
                }

                Spacer()

                if currentStep < 5 {
                    Button("Next") {
                        goToNextStep()
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                } else {
                    Button("Finish") {
                        finishTutorial()
                    }
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            }
            .padding(.horizontal)
        }
        .navigationBarHidden(true)
    }

    private func skipTutorial() {
        hasCompletedTutorial = true
        navigateToHomeView()
    }

    private func finishTutorial() {
        hasCompletedTutorial = true
        appViewModel.notificationFrequency = notificationFrequency
        appViewModel.caffeineLimit = cupLimit
        appViewModel.spendingLimit = spendingLimit
        appViewModel.controlPreference = controlPreference
        print("Preferences saved: Notifications = \(notificationFrequency), Cups = \(cupLimit), Spending = \(spendingLimit), Control = \(controlPreference)")
        
        appViewModel.hasCompletedTutorial = true
        appViewModel.isUserAuthenticated = true
        navigateToHomeView()
    }

    private func goToNextStep() {
        if currentStep < 5 {
            currentStep += 1
        }
    }

    private func navigateToHomeView() {
        appViewModel.isLoading = false // Ensure loading state is off
        presentationMode.wrappedValue.dismiss() // Close tutorial and navigate
    }

    private func scheduleNotifications() {
        let calendar = Calendar.current
        let now = Date()

        // Calculate notification times
        notificationTimes = (1...notificationFrequency).compactMap { step in
            let interval = (24 * 60 * 60) / notificationFrequency // Divide the day equally
            return calendar.date(byAdding: .second, value: step * interval, to: now)
        }
    }
}


#Preview {
    NavigationView {
        TutorialView()
            .environmentObject(AppViewModel()) // Provide the environment object
    }
}
