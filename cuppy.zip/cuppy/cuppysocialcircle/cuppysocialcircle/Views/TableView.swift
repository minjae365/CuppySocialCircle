//
//  TableView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-20.
//

import SwiftUI

struct TableView: View {
    @ObservedObject var drinkViewModel = DrinkViewModel()
    @State private var selectedFilter: String = "Daily"
    @State private var expandedDrink: String? = nil // Track the expanded drink
    let filters = ["Daily", "Weekly", "Monthly"]

    var body: some View {
        ZStack {
            Color("Beige").edgesIgnoringSafeArea(.all) // Beige background
            
            VStack {
                // Filter Picker
                Picker("Filter", selection: $selectedFilter) {
                    ForEach(filters, id: \.self) { filter in
                        Text(filter)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                if filteredDrinks.isEmpty {
                    Text("No drinks logged yet.")
                        .font(.headline)
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    List {
                        // "Today's Logs" only for Daily filter
                        if selectedFilter == "Daily" {
                            Section(header: Text("Today's Logs")) {
                                ForEach(todayDrinks) { drink in
                                    DisclosureGroup(
                                        isExpanded: Binding(
                                            get: { expandedDrink == drink.name },
                                            set: { expandedDrink = $0 ? drink.name : nil }
                                        )
                                    ) {
                                        // Individual logs with delete button
                                        ForEach(drink.logTimes.indices, id: \.self) { index in
                                            HStack {
                                                Text("Logged at: \(formatDate(drink.logTimes[index]))")
                                                    .font(.subheadline)
                                                    .foregroundColor(.gray)
                                                Spacer()
                                                Button(action: {
                                                    deleteLog(for: drink, at: index)
                                                }) {
                                                    Image(systemName: "trash")
                                                        .foregroundColor(.red)
                                                }
                                            }
                                        }
                                    } label: {
                                        HStack {
                                            Text(drink.name)
                                                .font(.headline)
                                            Spacer()
                                            Text("Count: \(drink.count)")
                                        }
                                    }
                                }
                            }
                        }

                        // Main Table with Drink Information
                        Section(header: Text("\(selectedFilter) Logs")) {
                            ForEach(filteredDrinks) { drink in
                                VStack(alignment: .leading) {
                                    Text(drink.name)
                                        .font(.headline)
                                    Text("Caffeine: \(drink.caffeine) mg")
                                    Text("Calories: \(drink.calories)")
                                    Text("Count: \(drink.count)")
                                    if let lastLog = drink.logTimes.last {
                                        Text("Last Logged: \(formatDate(lastLog))")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Drink Logs")
        }
    }

    // Filtered Logs Based on Selected Timeframe
    private var filteredDrinks: [Drink] {
        let calendar = Calendar.current
        let now = Date()

        return drinkViewModel.drinks.filter { drink in
            drink.logTimes.contains { logTime in
                switch selectedFilter {
                case "Daily":
                    return calendar.isDate(logTime, inSameDayAs: now)
                case "Weekly":
                    return calendar.isDate(logTime, equalTo: now, toGranularity: .weekOfYear)
                case "Monthly":
                    return calendar.isDate(logTime, equalTo: now, toGranularity: .month)
                default:
                    return false
                }
            }
        }
    }

    // Logs for the Current Day
    private var todayDrinks: [Drink] {
        let calendar = Calendar.current
        let now = Date()

        return drinkViewModel.drinks.filter { drink in
            drink.logTimes.contains { logTime in
                calendar.isDate(logTime, inSameDayAs: now)
            }
        }
    }

    // Delete a specific log
    private func deleteLog(for drink: Drink, at index: Int) {
        if let drinkIndex = drinkViewModel.drinks.firstIndex(where: { $0.name == drink.name }) {
            drinkViewModel.drinks[drinkIndex].logTimes.remove(at: index)
            if drinkViewModel.drinks[drinkIndex].logTimes.isEmpty {
                drinkViewModel.drinks.remove(at: drinkIndex)
            }
        }
    }

    // Format Date for Display
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}


#Preview {
    NavigationView {
        TableView()
            .environmentObject(AppViewModel())
            .environmentObject(DrinkViewModel())
    }
}
