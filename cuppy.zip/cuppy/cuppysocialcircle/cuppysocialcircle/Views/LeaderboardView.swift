import SwiftUI

struct LeaderboardView: View {
    @EnvironmentObject var appViewModel: AppViewModel
    @State private var friends: [Friend] = [
        Friend(name: "Alice", streak: 15),
        Friend(name: "Bob", streak: 10),
        Friend(name: "Charlie", streak: 7),
        Friend(name: "Diana", streak: 3)
    ]
    @State private var showAddFriendView: Bool = false

    var body: some View {
        ZStack {
            // Background color
            Color("Beige").edgesIgnoringSafeArea(.all)

            VStack {
                HStack {

                    Spacer()

                    Button(action: {
                        showAddFriendView = true
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(Color("Celadon"))
                    }
                }
                .padding()

                if friends.isEmpty {
                    EmptyStateView(message: "No friends to display. Add friends to compete!")
                } else {
                    List(sortedFriends) { friend in
                        HStack {
                            Text("#\(friend.rank)")
                                .font(.headline)
                                .foregroundColor(Color("Celadon"))
                                .frame(width: 40, alignment: .leading)

                            VStack(alignment: .leading) {
                                Text(friend.name)
                                    .font(.headline)
                                    .foregroundColor(Color("Bistre"))
                                Text("Streak: \(friend.streak) days")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }

                            Spacer()
                        }
                        .padding(.vertical, 8)
                    }
                    .listStyle(PlainListStyle())
                }

                Spacer()
            }
            .navigationTitle("Leaderboard")
            .sheet(isPresented: $showAddFriendView) {
                AddFriendView(friends: $friends)
            }
        }
    }

    private var sortedFriends: [RankedFriend] {
        let ranked = friends.enumerated().map { index, friend in
            RankedFriend(
                id: UUID(),
                name: friend.name,
                streak: friend.streak,
                rank: index + 1
            )
        }
        return ranked.sorted { $0.streak > $1.streak }
    }
}
// MARK: - Preview

struct AddFriendView: View {
    @Binding var friends: [Friend]
    @Environment(\.dismiss) var dismiss
    @State private var friendName: String = ""
    @State private var friendStreak: Int = 1

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("New Friend Details")) {
                    TextField("Name", text: $friendName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Stepper("Streak: \(friendStreak) days", value: $friendStreak, in: 1...100)
                }

                Section {
                    Button("Add Friend") {
                        addFriend()
                    }
                    .disabled(friendName.isEmpty)
                }
            }
            .navigationTitle("Add Friend")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }

    private func addFriend() {
        let newFriend = Friend(name: friendName, streak: friendStreak)
        friends.append(newFriend)
        dismiss()
    }
}

struct Friend: Identifiable {
    let id = UUID() // Unique identifier for the friend
    let name: String // Friend's name
    let streak: Int // Number of days in their streak
}

struct RankedFriend: Identifiable {
    let id: UUID // Use the UUID of the Friend
    let name: String // Friend's name
    let streak: Int // Friend's streak count
    let rank: Int // Friend's rank in the leaderboard
}



#Preview {
    LeaderboardView()
        .environmentObject(AppViewModel())
}
