import Foundation
import SwiftUI

struct SignUpView: View {
    @EnvironmentObject var appViewModel: AppViewModel // Access app state
    @Environment(\.presentationMode) var presentationMode // For dismissing the view
    @State private var email: String = ""
    @State private var id: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    @State private var navigateToTutorial: Bool = false // Add this state
    @State private var path: [String] = [] 
    private let credentialManager = CredentialManager()

    var body: some View {
            NavigationStack(path: $path) {
                        VStack(spacing: 20) {
                            Text("Create Your Account")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                                .padding(.bottom, 20)
                            TextField("Enter your ID", text: $id)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)

                            SecureField("Enter your Password", text: $password)
                                .textFieldStyle(RoundedBorderTextFieldStyle())

                            SecureField("Confirm your Password", text: $confirmPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())

                            Button(action: signUp) {
                                Text("Sign Up")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color("Celadon"))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .alert(isPresented: $showAlert) {
                            Alert(
                                title: Text("Sign Up"),
                                message: Text(alertMessage),
                                dismissButton: .default(Text("OK")) {
                                    if alertMessage == "Sign Up Successful!"{
                                        path.append("Tutorial") // Navigate to tutorial
                                    }
                                }
                            )
                        }
                        .navigationDestination(for: String.self) { destination in
                            if destination == "Tutorial" {
                                TutorialView()
                                    .environmentObject(appViewModel)
                            } else if destination == "MainTab" {
                                MainTabView()
                                    .environmentObject(appViewModel)
                                    .environmentObject(DrinkViewModel(userID: appViewModel.currentUser ?? "defaultUser"))
                            }
                        }
                    }
                }

    private func signUp() {
        guard !id.isEmpty, !password.isEmpty, !confirmPassword.isEmpty else {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        guard password == confirmPassword else {
            alertMessage = "Passwords do not match."
            showAlert = true
            return
        }

        if credentialManager.saveCredentials(id: id, password: password) {
            alertMessage = "Sign Up Successful!"
            appViewModel.currentUser = id
            appViewModel.hasCompletedTutorial = false // Set tutorial status
            appViewModel.isUserAuthenticated = true
        } else {
            alertMessage = "ID already exists. Please choose another."
        }
        showAlert = true
    }

    private func navigateToLogin() {
        // Navigate back to the LoginView after successful signup
        presentationMode.wrappedValue.dismiss()
    }
}

#Preview {
    NavigationView {
        SignUpView()
            .environmentObject(AppViewModel())
            .environmentObject(DrinkViewModel(userID: "mockUser"))
    }
}
