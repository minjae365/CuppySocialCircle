//
//  InputAnimationView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-19.
//

import Foundation
import SwiftUI

struct InputAnimationView: View {
    @Binding var show: Bool // Bind to control visibility
    let animationName: String // Name of the GIF or animation file
    let animationDuration: Double // Duration for the animation to stay visible

    var body: some View {
        if show {
            ZStack {
                Color.black.opacity(0.5) // Optional background overlay
                    .edgesIgnoringSafeArea(.all)

                VStack {
                    // Display the animation
                    LottieView(filename: "First_second")
                        .frame(width: 300, height: 300)
                    Text("Input Saved!")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.top, 10)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black.opacity(0.5))
                .cornerRadius(15)
            }
            .onAppear {
                // Automatically hide after the animation duration
                DispatchQueue.main.asyncAfter(deadline: .now() + animationDuration) {
                    show = false
                }
            }
        }
    }
}
