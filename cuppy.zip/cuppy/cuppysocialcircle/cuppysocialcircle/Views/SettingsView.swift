//
//  SettingsView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-19.
//

import Foundation
import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var appViewModel: AppViewModel
    @State private var notificationsEnabled: Bool = true
    @State private var notificationFrequency: Int = 2
    @State private var drinkLimit: Int = 3
    @State private var spendingLimit: Double = 10.0
    @State private var showAlert: Bool = false
    @AppStorage("userSignedIn") private var userSignedIn: Bool = true

    var body: some View {
        Form {
            // Preferences Section
            Section(header: Text("Preferences")) {
                // Toggle for Notifications
                Toggle("Enable Notifications", isOn: $notificationsEnabled)
                    .onChange(of: notificationsEnabled) { isEnabled in
                        if isEnabled {
                            NotificationManager.shared.scheduleNotifications(
                                reminderCount: notificationFrequency,
                                title: "Reminder from Cuppy!",
                                body: "Don't forget to log your drinks and stay within your limits!"
                            )
                        } else {
                            NotificationManager.shared.cancelAllNotifications()
                        }
                    }

                // Stepper for Notifications Frequency
                if notificationsEnabled {
                    Stepper("Notifications: \(notificationFrequency) times/day", value: $notificationFrequency, in: 1...10)
                        .onChange(of: notificationFrequency) { newValue in
                            NotificationManager.shared.scheduleNotifications(
                                reminderCount: newValue,
                                title: "Reminder from Cuppy!",
                                body: "Don't forget to log your drinks and stay within your limits!"
                            )
                        }
                }

                // Stepper for Drink Limit
                Stepper("Drink Limit: \(drinkLimit) cups/day", value: $drinkLimit, in: 1...10)
                    .onChange(of: drinkLimit) { newValue in
                        appViewModel.drinkLimit = newValue
                    }

                // Spending Limit with Slider
                HStack {
                    Text("Spending Limit: $\(spendingLimit, specifier: "%.2f")")
                    Spacer()
                    Slider(value: $spendingLimit, in: 1...50, step: 0.5)
                        .onChange(of: spendingLimit) { newValue in
                            appViewModel.spendingLimit = newValue
                        }
                }
            }

            // Save Changes Button
            Section {
                Button("Save Changes") {
                    savePreferences()
                }
            }
            
            Section(header: Text("Control Preferences")) {
                Picker("Choose:", selection: $appViewModel.controlPreference) {
                    Text("Caffeine").tag(ControlPreference.caffeine)
                    Text("Spending").tag(ControlPreference.spending)
                    Text("Both").tag(ControlPreference.both)
                }
                .pickerStyle(SegmentedPickerStyle())
            }

            // Sign-Out Button
            Section {
                Button("Sign Out") {
                    userSignedIn = false
                    showAlert = true
                }
                .foregroundColor(.red)
            }
        }
        .navigationTitle("Settings")
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Signed Out"),
                message: Text("You have been signed out."),
                dismissButton: .default(Text("OK"))
            )
        }
        .onAppear {
            NotificationManager.shared.requestNotificationPermissions()
            loadPreferences()
        }
    }

    // Save preferences to AppViewModel
    private func savePreferences() {
        appViewModel.notificationsEnabled = notificationsEnabled
        appViewModel.notificationFrequency = notificationFrequency
        appViewModel.drinkLimit = drinkLimit
        appViewModel.spendingLimit = spendingLimit
    }

    // Load preferences from AppViewModel
    private func loadPreferences() {
        notificationsEnabled = appViewModel.notificationsEnabled
        notificationFrequency = appViewModel.notificationFrequency
        drinkLimit = appViewModel.drinkLimit
        spendingLimit = appViewModel.spendingLimit
    }
}

#Preview {
    NavigationView {
        SettingsView()
            .environmentObject(AppViewModel())
    }
}
