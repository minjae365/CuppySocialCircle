//
//  cuppysocialcircleApp.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import SwiftUI

@main
struct CuppysCircleApp: App {
    @StateObject private var appViewModel = AppViewModel()
    @StateObject private var drinkViewModel = DrinkViewModel()
    @AppStorage("userSignedIn") private var userSignedIn: Bool = true
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                if appViewModel.isLoading {
                    LoadingView() // Show loading screen
                } else if !userSignedIn {
                    LoginView() // Show login screen if the user is not signed in
                        .environmentObject(appViewModel)
                } else if !appViewModel.hasCompletedTutorial {
                    TutorialView() // Show tutorial if not completed
                        .environmentObject(appViewModel)
                } else {
                    MainTabView() // Main app content
                        .environmentObject(appViewModel)
                        .environmentObject(drinkViewModel)
                }
            }
        }
    }
}
