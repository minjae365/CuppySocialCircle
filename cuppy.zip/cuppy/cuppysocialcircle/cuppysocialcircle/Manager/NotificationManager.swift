//
//  NotificationManager.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-19.
//

import Foundation
import UserNotifications

class NotificationManager {
    static let shared = NotificationManager()

    private init() {}

    func requestNotificationPermissions() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error {
                print("Error requesting notifications permissions: \(error.localizedDescription)")
            }
            print("Notifications permission granted: \(granted)")
        }
    }

    func scheduleNotifications(reminderCount: Int, title: String, body: String) {
        cancelAllNotifications() // Clear existing notifications first

        let calendar = Calendar.current
        let now = Date()
        let startOfDay = calendar.startOfDay(for: now)
        let interval = 24 / reminderCount // Divide day into equal intervals

        for i in 0..<reminderCount {
            let reminderTime = calendar.date(byAdding: .hour, value: i * interval, to: startOfDay) ?? now
            scheduleNotification(at: reminderTime, title: title, body: body)
        }
    }

    private func scheduleNotification(at date: Date, title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default

        let triggerDate = Calendar.current.dateComponents([.hour, .minute], from: date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: false)

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            }
        }
    }

    func cancelAllNotifications() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }
}
