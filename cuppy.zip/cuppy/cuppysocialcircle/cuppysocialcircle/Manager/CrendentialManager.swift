//
//  CrendentialManager.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-19.
//

import Foundation

class CredentialManager {
    private let credentialsKey = "userCredentials"

    // Save a new user's credentials
    func saveCredentials(id: String, password: String) -> Bool {
        var credentials = getCredentials()
        if credentials.keys.contains(id) {
            return false // ID already exists
        }
        credentials[id] = password
        saveCredentialsToDefaults(credentials: credentials)
        return true
    }

    // Validate login credentials
    func validateCredentials(id: String, password: String) -> Bool {
        let credentials = getCredentials()
        return credentials[id] == password
    }

    // Check if ID exists
    func idExists(id: String) -> Bool {
        let credentials = getCredentials()
        return credentials.keys.contains(id)
    }

    // Retrieve all saved credentials
    private func getCredentials() -> [String: String] {
        if let data = UserDefaults.standard.data(forKey: credentialsKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            return decoded
        }
        return [:]
    }

    // Save credentials dictionary to UserDefaults
    private func saveCredentialsToDefaults(credentials: [String: String]) {
        if let encoded = try? JSONEncoder().encode(credentials) {
            UserDefaults.standard.set(encoded, forKey: credentialsKey)
        }
    }
}
