//
//  PetModel.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import Foundation

struct Pet: Codable {
    var name: String
    var birthday: Date
    var caffeineCount: Int // Number of caffeinated drinks consumed
    var totalSpent: Int    // Total money spent on caffeinated drinks
    var streakCount: Int = 0 // Track the streak count
    var lastResetDate: Date?

    // Add a method to reset the streak
    mutating func resetStreak() {
        streakCount = 0
    }

    // Add a method to increment the streak
    mutating func incrementStreak() {
        streakCount += 1
    }
    
    var ageInDays: Int {
        calculateTimeSince(date: birthday)
    }
    
    var mood: String {
        if caffeineLevel == "Overloaded" || spendingLevel == "Broke" {
            return "Stressed"
        }
        return "Happy"
    }
    
    var caffeineLevel: String {
        if caffeineCount > 5 {
            return "Overloaded"
        }
        return "Moderate"
    }
    
    var spendingLevel: String {
        if totalSpent > 50 {
            return "Broke"
        }
        return "Within Budget"
    }
}

// Helper function for calculating time since a specific date
func calculateTimeSince(date: Date) -> Int {
    let calendar = Calendar.current
    let start = calendar.startOfDay(for: date)
    let end = calendar.startOfDay(for: Date())
    let components = calendar.dateComponents([.day], from: start, to: end)
    return components.day ?? 0
}
