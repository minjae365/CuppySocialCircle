//
//  LottieView.swift
//  cuppysocialcircle
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import Foundation
import SwiftUI
import Lottie

struct LottieView: UIViewRepresentable {
    let filename: String

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        let animationView = LottieAnimationView(name: filename)
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        animationView.play()

        animationView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(animationView)

        NSLayoutConstraint.activate([
            animationView.widthAnchor.constraint(equalToConstant: 400),
            animationView.heightAnchor.constraint(equalToConstant: 400),
            animationView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            animationView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}
