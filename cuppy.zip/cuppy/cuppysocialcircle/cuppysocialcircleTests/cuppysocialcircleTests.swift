//
//  cuppysocialcircleTests.swift
//  cuppysocialcircleTests
//
//  Created by Jade Minjae Kang on 2024-11-15.
//

import Testing

struct cuppysocialcircleTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
